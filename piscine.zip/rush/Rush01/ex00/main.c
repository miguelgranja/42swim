/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: joescude <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/03/29 13:45:56 by joescude          #+#    #+#             */
/*   Updated: 2025/03/29 16:08:13 by joescude         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>
#include <stdio.h>
int	validate_input(char *str);
void	convers_input(char *str, int *rules);

int main(int argc, char *argv[])
{
	//int grid[4][4];
	int rules[16];

	//grid = {0};
	if (argc != 2 || !validate_input(argv[1]))
	{
		write(1, "error\n", 6);
		return 0;
	}
	convers_input(argv[1], rules);


	return 0;

}

