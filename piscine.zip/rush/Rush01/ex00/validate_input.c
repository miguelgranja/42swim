/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   validate_input.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: joescude <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/03/29 13:47:54 by joescude          #+#    #+#             */
/*   Updated: 2025/03/29 16:12:20 by joescude         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */
#include <unistd.h>
#include <stdio.h>

int validate_input(char *str)
{
	int count;
	
	count = 0;

	while (*str)
	{
		if (*str >= '1' && *str <= '4')
		{
			count++;
		}
		else if(*str != ' ')
			return (0);
		str++;
	}
	if (count == 16)
		return (16);
	else
		return (0);
}
