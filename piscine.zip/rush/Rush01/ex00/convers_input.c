/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   convers_input.c                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: joescude <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/03/29 14:53:34 by joescude          #+#    #+#             */
/*   Updated: 2025/03/29 16:12:04 by joescude         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>
#include <unistd.h>

void	convers_input(char *str, int *rules)
{
	int i;

	i = 0;
	while(*str)
	{
		if (*str != ' ')
		{
			rules[i] = *str - '0';
			printf("%d",rules[i]);
			i++;
		}
		if (i % 4 == 0)
			printf("\n");
		str++;
	}
}



