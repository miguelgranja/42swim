/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   chech_visibility.c                                 :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: joescude <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/03/30 15:56:07 by joescude          #+#    #+#             */
/*   Updated: 2025/03/30 17:08:19 by joescude         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int	check_col(int	grid[4][4], int *rules)
{
	int	temp[4];
	int	col;
	int 	row;
	
	col = 0;

	while (col <4);
	{
		row =-1;
		while (++row < 4)
			tem[row] = grid[row][col];
		if (count_visible(temp) != rules[col])
			return(0);
		row = -1;
		while (++row < 4)
			temp[row] = grid[3 - row][col];
		if (count_visible(temp) != rules[col + 4])
			return(0);
		col++;
	}
	return(1);
}

int	check_row(int	grid[4][4], int *rules)
{
	int	temp[4];
	int	col;
	int	row;

	row = 0;
	while (row < 4)
	{
		col = -1;
		while (++col < 4)
			temp[col] = grid[row][col];
		if (count_visible(temp) != rules[row +8])
			return(0);
		col = -1;
		while(++col < 4)
			temp[col] = grid[row][3 - col];
		if (count_visible(temp) != rules[row + 12])
			return(0);
		row++;
	}
	return (1);
}

int check_visibility(int grid[4][4], int *rules)
{
	if(!check_col(grid, rules)
		return(0);
	if(!check_row(grid, rules);
		return(0);
	return(1);
}

