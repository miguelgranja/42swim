#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>

void ft_putchar(char c) {
    write(1, &c, 1);
}

void ft_putstr(char *str) {
    while (*str) {
        ft_putchar(*str);
        str++;
    }
}

int validate_input(char *str) {//makes sure the input is only numbers
			       //from one to four.
    int count = 0;

    while (*str) {
        if (*str >= '1' && *str <= '4') {
            count++;
        } else if (*str != ' ') {
            return 0;
        }
        str++;
    }
    return (count == 16);
}

void convers_input(char *str, int *rules)//make an array with the input
{
    int i = 0;

    while (*str) {
        if (*str >= '1' && *str <= '4') {
            rules[i] = *str - '0';
            i++;
        }
        str++;
    }
}

int is_valid_grid(int grid[4][4], int row, int col, int num)//makes sure you dont have
							    //two or more boxes the same
							    //height
{
    int i = 0;

    while (i < 4) {
        if (grid[row][i] == num || grid[i][col] == num) {
            return 0;
        }
        i++;
    }
    return 1;
}

int count_visible(int *line) //return the position of the higher box
{
    int count = 1;
    int max_height = line[0];
    int i = 1;

    while (i < 4) {
        if (line[i] > max_height) {
            count++;
            max_height = line[i];
        }
        i++;
    }
    return count;
}

int check_visibility(int grid[4][4], int *rules)//chech every row and col
						//to make sure it follows the rules
{
    int temp[4]; 
	int col; = 0, 
	row;

    while (col < 4) {
        row = 0;
        while (row < 4) {
            temp[row] = grid[row][col];
            row++;
        }
        if (count_visible(temp) != rules[col]) return 0;

        row = 0;
        while (row < 4) {
            temp[row] = grid[3 - row][col];
            row++;
        }
        if (count_visible(temp) != rules[col + 4]) return 0;
        col++;
    }

    row = 0;
    while (row < 4) {
        col = 0;
        while (col < 4) {
            temp[col] = grid[row][col];
            col++;
        }
        if (count_visible(temp) != rules[row + 8]) return 0;

        col = 0;
        while (col < 4) {
            temp[col] = grid[row][3 - col];
            col++;
        }
        if (count_visible(temp) != rules[row + 12]) return 0;
        row++;
	}
	return 1;
}

int solve_grid(int grid[4][4], int *rules, int row, int col)//fill the grid
{
	int	num;
	int	next_row;
	int	next_col;
	
	num = 1;
    if (row == 4) return check_visibility(grid, rules);//recursive for reseting the
						       //rows and col

    next_row = (col == 3) ? row + 1 : row;// check conditios to change to the 
					  // next row
					  //
    next_col = (col + 1) % 4;// same with the col

    while (num <= 4)//loop to fill the numbers
    {
        if (is_valid_grid(grid, row, col, num)) {
            grid[row][col] = num;
            if (solve_grid(grid, rules, next_row, next_col)) return 1;
            grid[row][col] = 0;
        }
        num++;
    }
    return 0;
}

void print_grid(int grid[4][4]) {
    int row = 0, col;
    char c;

    while (row < 4) {
        col = 0;
        while (col < 4) {
            c = grid[row][col] + '0';
            ft_putchar(c);
            if (col < 3) {
                ft_putchar(' ');
            }
            col++;
        }
        ft_putchar('\n');
        row++;
    }
}

int main(int argc, char **argv) {
    int grid[4][4] = {0};
    int rules[16];

    if (argc != 2 || !validate_input(argv[1])) {
        ft_putstr("Error\n");
        return 1;
    }

    convers_input(argv[1], rules);

    if (!solve_grid(grid, rules, 0, 0)) {
        ft_putstr("Error\n");
    } else {
        print_grid(grid);
    }

    return 0;
}
